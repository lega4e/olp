#include <iostream>


using namespace std;





// functions
int dp(int l, int r, vector<int>& memo)
{
	if(l == r) return 0;
	int res = dp;
}





// main
int main( int argc, char *argv[] )
{
	



	return 0;
}





// end
